<?php
$con = mysqli_connect("localhost","root","root","student");
if (!$con){
  die('Could not connect: ' . mysqli_error());
  }
mysqli_select_db($con,"student");

$patient_id= $_REQUEST['patient_id'];


$query = "SELECT * FROM PatientInfo where patient_id='$patient_id' ";
$result= mysqli_query($con,$query) or die('Query failed: ' . mysqli_error());
$row = mysqli_fetch_array($result);

if($row!= NULL)
{
?>
<html style="background-image: url('dental.jpg');background-repeat: no-repeat;background-attachment: fixed;background-size: cover;">
<br><br>
<center>

<h2 style="font-size:40px;  color: white; font-family: gabriola; font-size: 300%;">Fill in New Patient Details</h2>

<form action="edit_patient_success.php" method="POST">
<table cellpadding=2 cellspacing=2 border="0">
<input type="hidden" name="patient_id" value="<?php echo $row['patient_id']; ?>" >


<tr>
<th> First Name: </th>
<td><input name="fname" type="text" value="<?php echo $row['FName']; ?>"></td>
</tr>

<tr>
<th> Last Name: </th>
<td><input name="lname" type="text" value="<?php echo $row['LName']; ?>"></td>
</tr>

<tr>
<th> Date of Birth: </th>
<td><input name="dob" type="text" value="<?php echo $row['DOB']; ?>"></td>
</tr>

<tr>
<th> Gender: </th>
<td><input name="gender" type="text" value="<?php echo $row['Gender']; ?>"></td>
</tr>

<tr>
<th>Email</th>
<td><input name="email" type="text" value="<?php echo $row['Email']; ?>"></td>
</tr>

<tr>
<th>Phone Number</th>
<td><input name="phone" type="text" value="<?php echo $row['Phone_No']; ?>"></td>
</tr>

<tr>
<th>Street</th>
<td><input name="street" type="text" value="<?php echo $row['Street']; ?>"></td>
</tr>

<tr>
<th>State</th>
<td><input name="state" type="text" value="<?php echo $row['State']; ?>"></td>
</tr>

<tr>
<th>City</th>
<td><input name="city" type="text" value="<?php echo $row['City']; ?>"></td>
</tr>

<tr>
<th>Zip Code</th>
<td><input name="zip" type="text" value="<?php echo $row['Zip']; ?>"></td>
</tr>

<tr>
<th>Primary Doctor</th>
<td><input name="primdr" type="text" value="<?php echo $row['PrimaryDoctor']; ?>"></td>
</tr>

<tr><th> </th><td> </td></tr>

<tr>
<td><input type="submit" value="Update Patient" /></td>
<td><input type="Reset" value="Reset" /></td>

</tr>

</form>

</center>
</html>
<?php
}
?>