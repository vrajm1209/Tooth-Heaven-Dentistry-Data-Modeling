<?php
// echo is used to output text with php
echo "COVID DISCLOSURE";
echo "<br/>";

// creating a connection to the database
$con = mysqli_connect("localhost","root","root","student");

// if connection to the database fails an error is thrown
if (!$con){
  die('Could not connect: ' . mysqli_error());
}
  
// selecting the database for the connection created  
mysqli_select_db($con,"student");

// storing the query in a variable called $query
$query=
("INSERT INTO coviddiclosures(Cough,Fever,Sore Throat,FourteenDayExpo,Date)
VALUES ('{$_POST['cough']}','{$_POST['fever']}','{$_POST['sorethroat']}','{$_POST['forexpo']}','{$_POST['date']}' ");

 // executing the query
mysqli_query($con,$query);

//closing the connection
mysqli_close($con);

echo "<br/>";
echo "<p>Cough - {$_POST['cough']} </p> <br/>";
echo "<p>Fever - {$_POST['fever']} </p> <br/>";
echo "<p>Sore Throat - {$_POST['sorethroat']} </p> <br/>";
echo "<p>14 Day Exposure - {$_POST['forexpo']} </p> <br/>";
echo "<p>Date - {$_POST['date']} </p> <br/>";

echo "<a href='home.php'>Home</a><br/>";
?>