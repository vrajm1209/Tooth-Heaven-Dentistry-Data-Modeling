<?php
$con = mysqli_connect("localhost","root","root","student");
if (!$con){ die('Could not connect: ' . mysqli_error()); }
mysqli_select_db($con,"student");

?>

<html style="background-image: url('istockphoto-1196021900-612x612.jpg');background-repeat: no-repeat;background-attachment: fixed;background-size: cover;">
<br><br>
<center>
<div>
<h2 style="font-size:40px;  color: black; font-family: Berlin Sans FB Demi; font-size: 300%;">All Patients</h2>

<?php

 $query = "SELECT * FROM PatientInfo ";
 $result= mysqli_query($con,$query) or die('Query failed: ' . mysqli_error()); 
 $numresults= mysqli_query($con,$query);
 $numrows=mysqli_num_rows($numresults);

 if ($numrows == 0){
    echo ("<h3>No match Found</h3>");
}
 	
 else	
 {	
?>
<table border='1' style="font-size:20px;  color: black; font-family: times new roman;">
<tr>
<th>First Name</td>
<th>Last Name</td>
<th>Date of Birth</td>
<th>Gender</td>
<th>Email</td>
<th>Phone_No</td>
<th>Street</td>
<th>State</td>
<th>City</td>
<th>Zip Code</td>
<th>Primary Doctor</td>
<th>Action</td>
</tr>

<?php
while($row = mysqli_fetch_array($result))
 { 
 ?>
 
<tr>
<td><?php echo $row['FName']; ?></td>
<td><?php echo $row['LName']; ?></td>
<td><?php echo $row['DOB']; ?></td>
<td><?php echo $row['Gender']; ?></td>
<td><?php echo $row['Email']; ?></td>
<td><?php echo $row['Phone_No']; ?></td>
<td><?php echo $row['Street']; ?></td>
<td><?php echo $row['State']; ?></td>
<td><?php echo $row['City']; ?></td>
<td><?php echo $row['Zip']; ?></td>
<td><?php echo $row['PrimaryDoctor']; ?></td>

<td><a href="covid_info.php?patient_id=<?php echo $row['patient_id']; ?>">Disclosure</a>&nbsp;
</td>
</tr>
<?php 
  
   }  //end of while
   
 }  //end of else i.e match is found
 ?>
 </table>
</center>
</html>