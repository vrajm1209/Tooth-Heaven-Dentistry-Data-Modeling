<html>
<?php
$con = mysqli_connect("localhost","root","root","student");

if (!$con){ die('Could not connect: ' . mysqli_error()); }

mysqli_select_db($con,"student");

$patient_id=$_POST['patient_id'];
$fname= $_POST['fname'];
$lname= $_POST['lname'];
$dob= $_POST['dob'];
$gender= $_POST['gender'];
$email= $_POST['email'];
$phone= $_POST['phone'];
$street= $_POST['street'];
$state= $_POST['state'];
$city= $_POST['city'];
$zip= $_POST['zip'];
$primdr= $_POST['primdr'];

 
$query  = "
UPDATE PatientInfo
SET FName='$fname',LName='$lname',DOB='$dob',Gender='$gender',Email='$email',Phone_No='$phone',Street='$street',State='$state',City='$city',Zip='$zip',PrimaryDoctor='$primdr'
WHERE patient_id='$patient_id' " ;

mysqli_query($con,$query);

echo " <p>First Name - {$_POST['fname']} </p> <br/> ";
echo " <p>Last Name - {$_POST['lname']} </p> <br/> ";
echo " <p>Date of Birth - {$_POST['dob']} </p> <br/> ";
echo " <p>Gender - {$_POST['gender']} </p> <br/> ";
echo " <p>Email - {$_POST['email']} </p> <br/>";
echo " <p>Phone number - {$_POST['phone']} </p> <br/>";
echo " <p>Street - {$_POST['street']} </p> <br/>";
echo " <p>State - {$_POST['state']} </p> <br/>";
echo " <p>City - {$_POST['city']} </p> <br/>";
echo " <p>Zip Code - {$_POST['zip']} </p> <br/>";
echo " <p>Primary Doctor - {$_POST['primdr']} </p> <br/>";

echo "<a href='home.php'>Home</a><br/>";
?>
</html>