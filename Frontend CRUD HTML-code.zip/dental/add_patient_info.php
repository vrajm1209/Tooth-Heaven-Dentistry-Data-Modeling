<?php
?>
<html style="background-image: url('dental.jpg');background-repeat: no-repeat;background-attachment: fixed;background-size: cover;">
<form action="add_patient_info_success.php" method="post">
<div>
<br><br>
<center>
<h1 style=" position:absolute; left:650px; top:30px; color: white; font-family: Berlin Sans FB Demi; font-size: 200%;">TOOTH HEAVEN DENTISTRY</h1>
</center>
<!-- <h3>IMPORTANT NOTE!!! 6210</h3>
<h3> We are not going to enter the id since it is auto incremented in the mysql database</h3> -->

 
<h3 style = "position:absolute; left:600px; top:100px;">First Name :</h3><input    type = 'text' name='fname' style = "position:absolute; left:600px; top:140px;">
<h3 style = "position:absolute; left:950px; top:100px;">Last Name :</h3><input    type = 'text' name='lname' style = "position:absolute; left:950px; top:140px;">
<h3 style = "position:absolute; left:600px; top:180px;">Date of Birth :</h3><input   type = 'text' name='dob_tf' style = "position:absolute; left:600px; top:220px;">
<h3 style = "position:absolute; left:950px; top:180px;">Gender :</h3><input   type = 'text' name='gender_tf' style = "position:absolute; left:950px; top:220px;">
<h3 style = "position:absolute; left:600px; top:260px;">Phone No :</h3><input type = 'text' name='pno_tf' style = "position:absolute; left:600px; top:300px;">
<h3 style = "position:absolute; left:950px; top:260px;">Email Id :</h3><input type = 'text' name='email_tf' style = "position:absolute; left:950px; top:300px;">
<h3 style = "position:absolute; left:600px; top:340px;">Street :</h3><input type = 'text' name='street_tf' style = "position:absolute; left:600px; top:380px;">
<h3 style = "position:absolute; left:950px; top:340px;">State :</h3><input type = 'text' name='state_tf' style = "position:absolute; left:950px; top:380px;">
<h3 style = "position:absolute; left:600px; top:420px;">City :</h3><input type = 'text' name='city_tf' style = "position:absolute; left:600px; top:460px;">
<h3 style = "position:absolute; left:950px; top:420px;">Zip Code :</h3><input type = 'text' name='zip_tf' style = "position:absolute; left:950px; top:460px;"><br><br>
<h3 style = "position:absolute; left:600px; top:500px;">Primary Doctor :</h3><input type = 'text' name='primdr_tf' style = "position:absolute; left:600px; top:540px;">

<input type = 'submit' style = "position:absolute; left:950px; top:530px;">

</form>
</html> 