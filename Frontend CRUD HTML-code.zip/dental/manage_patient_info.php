<html style="background-image: url('dental.jpg');background-repeat: no-repeat;background-attachment: fixed;background-size: cover;">
<br><br><br><br><br>
<head>
<style>
.button {
  border: none;
  color: white;
  padding:3px 6px;
  text-align: center;
  text-decoration: none;
  display: inline-block;
  font-size: 10px;
  margin: 4px 2px;
  transition-duration: 0.4s;
  cursor: pointer;
}

.button1 {
  background-color: white; 
  color: black; 
  border: 2px solid #4CAF50;
}

.button1:hover {
  background-color: #4CAF50;
  color: white;
}

.button2 {
  background-color: white; 
  color: black; 
  border: 2px solid #008CBA;
}

.button2:hover {
  background-color: #008CBA;
  color: white;
}

</style>
</head>
								 <center>
								 <h2 style="font-size:40px;  color: white; font-family: Berlin Sans FB Demi; font-size: 300%;">MANAGE PATIENT INFORMATION</h2>
                                 
                                 <a href='add_patient_info.php'><button class="button button2"><h2>Add Patient</h2></button></a>
                                 <form action='search_patient.php' method='get'>
                                 <input type ='text' name='searchtext'>
								 <input type='submit' value='Search'>
								 </form>
                                 <center>
</html>