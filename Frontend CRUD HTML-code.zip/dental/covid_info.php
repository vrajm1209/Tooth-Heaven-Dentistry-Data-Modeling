<?php
?>
<html style="background-image: url('dental.jpg');background-repeat: no-repeat;background-attachment: fixed;background-size: cover;">
<form action="covid_info_success.php" method="post">
<div>
<br><br>
<center>

<h3 style=" position:absolute; left:700px; top:40px; color: white; font-family: Berlin Sans FB Demi; font-size: 200%;">COVID DISCLOSURE</h3>

</center>
<!-- <h3>IMPORTANT NOTE!!! 6210</h3>
<h3> We are not going to enter the id since it is auto incremented in the mysql database</h3> -->

 
<h3 style = "position:absolute; left:600px; top:100px;">Cough :</h3><input    type = 'text' name='cough' style = "position:absolute; left:600px; top:140px;">
<h3 style = "position:absolute; left:950px; top:100px;">Fever :</h3><input    type = 'text' name='fever' style = "position:absolute; left:950px; top:140px;">
<h3 style = "position:absolute; left:600px; top:180px;">Sore Throat :</h3><input   type = 'text' name='sorethroat' style = "position:absolute; left:600px; top:220px;">
<h3 style = "position:absolute; left:950px; top:180px;">14 Day Exposure :</h3><input   type = 'text' name='forexpo' style = "position:absolute; left:950px; top:220px;">
<h3 style = "position:absolute; left:600px; top:260px;">Date :</h3><input type = 'text' name='date' style = "position:absolute; left:600px; top:300px;">

<input type = 'submit' style = "position:absolute; left:950px; top:300px;">

</form>
</html> 