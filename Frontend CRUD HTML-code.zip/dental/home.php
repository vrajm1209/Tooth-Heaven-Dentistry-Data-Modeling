<html style="background-image: url('dental.jpg');background-repeat: no-repeat;background-attachment: fixed;background-size: cover;">
<head>
<style>
.button {
  border: none;
  color: white;
  padding: 16px 32px;
  text-align: center;
  text-decoration: none;
  display: inline-block;
  font-size: 16px;
  margin: 4px 2px;
  transition-duration: 0.4s;
  cursor: pointer;
}

.button1 {
  background-color: white; 
  color: black; 
  border: 2px solid #4CAF50;
}

.button1:hover {
  background-color: #4CAF50;
  color: white;
}

.button2 {
  background-color: white; 
  color: black; 
  border: 2px solid #008CBA;
}

.button2:hover {
  background-color: #008CBA;
  color: white;
}

</style>
</head>

								 <br><br><br><br><br>
								 <center>
                                 <h1 style="font-size:40px;  color: white; font-family: Berlin Sans FB Demi; font-size: 300%;">TOOTH HEAVEN DENTISTRY</h1>
                                 <a href='manage_patient_info.php'><button class="button button2">Manage patient information</button></a></br>
                                 <a href='covid_patients.php'><button class="button button2">Manage Covid Disclosure Form</button></a></br>
                                 <a href=''><button class="button button2">Manage doctor information</button></a></br>
                                 <a href=''><button class="button button2">Manage clinics information</button></a></br>
								 </center>
                                 
</body>
</html>