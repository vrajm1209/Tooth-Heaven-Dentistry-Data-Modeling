<?php
// echo is used to output text with php
echo "PATIENT INFO";
echo "<br/>";

// creating a connection to the database
$con = mysqli_connect("localhost","root","root","student");

// if connection to the database fails an error is thrown
if (!$con){
  die('Could not connect: ' . mysqli_error());
}
  
// selecting the database for the connection created  
mysqli_select_db($con,"student");

// storing the query in a variable called $query
$query=
("INSERT INTO PatientInfo(FName,LName,DOB,Gender,Email,Phone_No,Street,State,City,Zip,PrimaryDoctor)
VALUES ('{$_POST['fname']}','{$_POST['lname']}','{$_POST['dob_tf']}','{$_POST['gender_tf']}','{$_POST['email_tf']}',
'{$_POST['pno_tf']}','{$_POST['street_tf']}','{$_POST['state_tf']}','{$_POST['city_tf']}','{$_POST['zip_tf']}',
'{$_POST['primdr_tf']}') ");

 // executing the query
mysqli_query($con,$query);

//closing the connection
mysqli_close($con);

echo "<br/>";
echo "<p>First Name - {$_POST['fname']} </p> <br/>";
echo "<p>Last Name - {$_POST['lname']} </p> <br/>";
echo "<p>Date of Birth - {$_POST['dob_tf']} </p> <br/>";
echo "<p>Gender - {$_POST['gender_tf']} </p> <br/>";
echo "<p>Email ID - {$_POST['email_tf']} </p> <br/>";
echo "<p>Phone No - {$_POST['pno_tf']} </p> <br/>";
echo "<p>Street - {$_POST['street_tf']} </p> <br/>";
echo "<p>State - {$_POST['state_tf']} </p> <br/>";
echo "<p>City - {$_POST['city_tf']} </p> <br/>";
echo "<p>Zip - {$_POST['zip_tf']} </p> <br/>";
echo "<p>Primary Doctor - {$_POST['primdr_tf']} </p> <br/>";

echo "<a href='home.php'>Home</a><br/>";
?>