<html>
<?php
$con = mysqli_connect("localhost","root","root","student");
if (!$con){ die('Could not connect: ' . mysqli_error()); }
mysqli_select_db($con,"student");

$patient_id= $_REQUEST['patient_id'];
 
$query  = " DELETE FROM PatientInfo
WHERE patient_id='$patient_id' " ;

mysqli_query($con,$query);  
?>
<h3> Patient has been deleted ! </h3> <br/>

<a href='home.php'>Home</a><br/>

</html>